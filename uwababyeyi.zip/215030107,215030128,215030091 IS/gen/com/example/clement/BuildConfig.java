/** Automatically generated file. DO NOT MODIFY */
package com.example.clement;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}