package com.example.clement;


import android.app.Activity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.View.OnClickListener;

public class MainActivity extends Activity {
	 Button contextmenu;
	   

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        contextmenu=(Button) findViewById(R.id.contextmenu);
        registerForContextMenu(contextmenu);
        
        
Button btnclose = (Button) findViewById(R.id.Button);
    	
        btnclose.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				exit();
			}
		});
        }
    
    public void exit()
    {
    	
    	finish();
		System.exit(0);
    }
 
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
    		ContextMenuInfo menuInfo) {
    	// TODO Auto-generated method stub
    	super.onCreateContextMenu(menu, v, menuInfo);
    	MenuInflater inflater=getMenuInflater();
    	inflater.inflate(R.menu.main, menu);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

   
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId())
        {
        case R.id.you:
        	exit();
  			default:
  			return super.onOptionsItemSelected(item);
        }

    }
    
    /*    creating context menu when it inflating*/
    
    
    
    
  
    
    @Override
    public boolean onContextItemSelected(MenuItem item)
    {
    	 switch (item.getItemId())
         {
         case R.id.you:
        	 exit();
   			default:
   			return super.onContextItemSelected(item);
         }}
}
